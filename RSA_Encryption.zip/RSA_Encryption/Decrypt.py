from Crypto.PublicKey import RSA
import sys
"""
This program takes an encrypted message, the public and private keys, and decrypts the message
and returns it as a list 

"""



"""
This dictionary is how messages are converted into a number that can then be encrypted.

"""
mapDict = {'A': 1,
'B': 2,
'C': 3,
'D': 4,
'E': 5,
'F': 6,
'G': 7,
'H': 8,
'I': 9,
'J': 10,
'K': 11,
'L': 12,
'M': 13,
'N': 14,
'O': 15,
'P': 16,
'Q': 17,
'R': 18,
'S': 19,
'T': 20,
'U': 21,
'V': 22,
'W': 23,
'X': 24,
'Y': 25,
'Z': 26,
'a': 27,
'b': 28,
'c': 29,
'd': 30,
'e': 31,
'f': 32,
'g': 33,
'h': 34,
'i': 35,
'j': 36,
'k': 37,
'l': 38,
'm': 39,
'n': 40,
'o': 41,
'p': 42,
'q': 43,
'r': 44,
's': 45,
't': 46,
'u': 47,
'v': 48,
'w': 49,
'x': 50,
'y': 51,
'z': 52,
'0': 53,
'1': 54,
'2': 55,
'3': 56,
'4': 57,
'5': 58,
'6': 59,
'7': 60,
'8': 61,
'9': 62,
'!': 63,
'"': 64,
'#': 65,
'$': 66,
'%': 67,
'&': 68,
'\'': 69,
'(': 70,
')': 71,
'*': 72,
'+': 73,
',': 74,
'-': 75,
'.': 76,
'/': 77,
':': 78,
';': 79,
'<': 80,
'=': 81,
'>': 82,
'?': 83,
'@': 84,
'[': 85,
'\\': 86,
']': 87,
'^': 88,
'_': 89,
'`': 90,
'{': 91,
'|': 92,
'}': 93,
'~': 94,
' ': 95 }
"""
This class contains the method to decrypt the message
"""
class decrypt():

    def __init__(self):
        self.mykeyPrivate = 0
        self.mykeyPublic = 0

    """
    this method decrypts a message 
    Parameter 1: encrypt is a list that is the encrypted message
    Parameter 2: d, this is an integer and it is the private key produced in file "Generate_Public_&_Private_Keys.py"
    Parameter 3: N is and integer and it is the public key produced in file "Generate_Public_&_Private_Keys.py"
    Returns a list of the decrypted message. It is mapped back to its original form.
    """
    def decrypt(self, encrypt, d, N):
        decrytpString = ""
        decryptList = []
        for  i in encrypt:
            #m = (i ** d) % (N) This freezes the program 
            m = pow(i, d, N)#modular exponentiation ((i^d) % N)
            decryptList.append(m)
        for i in decryptList:
            for n,v in mapDict.items():
                if i == v:
                    decrytpString += n
        return decrytpString
    """
    This method takes a csv file containing the encrypted message and converts it into a list and 
    makes it apart of the object
    Parameter 1: csvFile a string with the name of a csv file 
    returns a list with integers that represent an encrypted message 
    """
    def encryptList(self, csvFile):
        encryptedListInt = []
        with open(csvFile, "r") as f:#Open and read csv file 
            encryptedString = f.read()
            encryptedListStr = encryptedString.split(",") #Get a list of the csv file 
            for string in encryptedListStr:#Convert list of strings to a list of integers 
                encryptedListInt.append(int(string))
            
            return encryptedListInt


    """
    This method imports the public and private key to decrypt the message
    """
    def importPrivateAndPublic(self):
        pwd = b'woV_mFR%b=,*]DkCCN%+'
        with open("myprivatekey.pem", "rb") as f:#Import private key
            data = f.read()
            self.mykeyPrivate = RSA.import_key(data, pwd)
        f.close()

        with open("mypublickey.pem", "r") as f:#Import public key
            data = f.read()
            self.mykeyPublic = RSA.import_key(data)
        f.close()
   
    """
    This method uses public and private keys to decrypt a csv file and output a txt file with the message
    Prodcues a .txt file
    """
    def exportDecryptedMsg(self):
        with open("DecryptedMessage.txt", "w") as f:

            data = original.decrypt(original.encryptList(sys.argv[1]), original.mykeyPrivate.d, original.mykeyPublic.n)
            f.write(data)
        f.flush()
        f.close()


original = decrypt()
original.importPrivateAndPublic()#Import public and private keys
#Decrypt a message and output it to a txt file
original.exportDecryptedMsg()
