
import java.io.File;
import java.util.Scanner;
public class RSA_Driver{


    /*
    This function runs the key generation python scrypt
    Prodcues two .pem files containing the public and private keys
     */
    static void generate(){
        //This runs the python script 
        try{
        Process pyRSA = new ProcessBuilder("python", "Generate_Public_&_Private_Keys_1.1.py").start();
        pyRSA.waitFor();
        
        }
        catch(Exception e){

        }
        //This runs the python script
    }



    /*
    This function runs the encryption python stript and encrypts a string
    Parameter 1: String to encrypt
    Produces a csv file that contains the encrypted string
     */
    static void encrypt(String stringToEncrypt){
        //This runs the python script 
        try{
        Process pyRSA = new ProcessBuilder("python", "Encrypt.py", stringToEncrypt).start();
        pyRSA.waitFor();
        
        }
        catch(Exception e){

        }
        //This runs the python script
        
    }

    /*
    This function runs the decryption python script,and prints the string
    Parameter 1: String, file name of the csv file containing the encrypted message
    Prints the decrypted message
     */
    static void decrypt(String csvFile){
        
        //This runs the python script 
        try{
        Process pyRSA = new ProcessBuilder("python", "Decrypt.py", csvFile).start();
        pyRSA.waitFor();//Wait until the python script is finished before preceding 
        
        }
        catch(Exception e){

        }
        
        //This runs the python script
       
        
    }


    /*
    This function prompts the user to make a choice

    */    
    static void prompt(){
        System.out.println("...........Enter a number............");
        System.out.println("");
        System.out.println("=====================================");
        System.out.println("|\t 1. Generate keys \t    |");
        System.out.println("|\t 2. Encrypt a message. \t    |");
        System.out.println("|\t 3. Decrypt a message. \t    |");
        System.out.println("|\t 4. q to quit \t            |");
        System.out.println("=====================================");
    }

    /*
    This function takes in user input and runs the correlated function

    */   
    static void userInput(){
        Scanner scnr = new Scanner(System.in);
        
        String userInput ;
        String empty = "";
        
        
        do {
            
                prompt(); //Prompt the user
                //empty = scnr.nextLine();
                //empty = scnr.nextLine();
                userInput = scnr.next();
                
                switch(userInput){
                    
                case "1":
                generate(); //Generate keys 
                    break;
                case "2": //Encrypt a message
                    
                    System.out.println("");
                    System.out.print("Enter message: ");
                    empty = scnr.nextLine();
                    String message = scnr.nextLine();
                    //System.out.println("");
                    System.out.println("Encrypting...");
                    encrypt(message);
                    System.out.println("Encrypted ;)");
                    break;
                case "3": //Decrypt a message
                    
                    
                    System.out.println();
                    System.out.println("Decrypting...");
                    decrypt("encryptedCSV.csv");
                    System.out.println("Decrypted ;D");
                    System.out.println("Decrypted message... ");
                    display();
                    

                    //System.out.println(display());
                    break;
                case "q"://Quit
                    System.out.println("GoodBye");
                    break;
                default:
                    System.out.println("Enter a valid number.");
                    System.out.println("");
            }
        }while(!userInput.equals("q"));
    }

    /* This function displays the decrypted .txt file 
    Returns a String of the decrypted message
    */
    static void display(){
        
        
        String decryptedString = "";
        try{
        File f = new File("DecryptedMessage.txt");
        
        Scanner scnr = new Scanner(f);
        //empty = scnr.nextLine();
        while(scnr.hasNextLine()){
            decryptedString = scnr.nextLine();
            System.out.println(decryptedString);
        }
        }
        catch(Exception e){

        }
    }
        //return decryptedString;
    
    public static void main(String[] args){

        userInput();


            
    }
}

