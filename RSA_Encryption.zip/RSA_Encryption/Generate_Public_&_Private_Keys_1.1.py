from Crypto.PublicKey import RSA
"""
This program generates the public and private keys for the RSA algorithm 
It uses 4096 bit encryption
"""



"""
This class generates the public and private keys for the RSA encryption algorithm and saves them to a .pem file
"""
class generate():
    #Constructor 
    def __init__(self):
        self.mykey = mykey = RSA.generate(4096)
    """
    This method generates the private keys and outputs it to a .pem file that is encrypted with 
    a password as the string pwd
    """
    def generatePrivateKey(self):
        
        pwd = b'woV_mFR%b=,*]DkCCN%+'
        with open("myprivatekey.pem", "wb") as f:
            data = self.mykey.export_key(passphrase=pwd,
                                        pkcs=8,
                                        protection='PBKDF2WithHMAC-SHA512AndAES256-CBC',
                                        prot_params={'iteration_count':131072})
            f.write(data)
    
    """
    This method generates and outputs the public key to a .pem file 
    """
    def generatePublicKey(self):
        with open("mypublickey.pem", "wb") as f:
            data = self.mykey.public_key().export_key()
            f.write(data)



gen = generate()
gen.generatePrivateKey()
gen.generatePublicKey()