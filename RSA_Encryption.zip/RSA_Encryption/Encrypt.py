from Crypto.PublicKey import RSA
import sys
"""
This Program takes a public key as input, maps messages to a number, then uses the public key to encrypt the message.
It produces a variable with the encrypted message 

"""


"""
This dictionary is how messages are converted into a number that can then be encrypted.

"""
mapDict = {'A': 1,
'B': 2,
'C': 3,
'D': 4,
'E': 5,
'F': 6,
'G': 7,
'H': 8,
'I': 9,
'J': 10,
'K': 11,
'L': 12,
'M': 13,
'N': 14,
'O': 15,
'P': 16,
'Q': 17,
'R': 18,
'S': 19,
'T': 20,
'U': 21,
'V': 22,
'W': 23,
'X': 24,
'Y': 25,
'Z': 26,
'a': 27,
'b': 28,
'c': 29,
'd': 30,
'e': 31,
'f': 32,
'g': 33,
'h': 34,
'i': 35,
'j': 36,
'k': 37,
'l': 38,
'm': 39,
'n': 40,
'o': 41,
'p': 42,
'q': 43,
'r': 44,
's': 45,
't': 46,
'u': 47,
'v': 48,
'w': 49,
'x': 50,
'y': 51,
'z': 52,
'0': 53,
'1': 54,
'2': 55,
'3': 56,
'4': 57,
'5': 58,
'6': 59,
'7': 60,
'8': 61,
'9': 62,
'!': 63,
'"': 64,
'#': 65,
'$': 66,
'%': 67,
'&': 68,
'\'': 69,
'(': 70,
')': 71,
'*': 72,
'+': 73,
',': 74,
'-': 75,
'.': 76,
'/': 77,
':': 78,
';': 79,
'<': 80,
'=': 81,
'>': 82,
'?': 83,
'@': 84,
'[': 85,
'\\': 86,
']': 87,
'^': 88,
'_': 89,
'`': 90,
'{': 91,
'|': 92,
'}': 93,
'~': 94,
' ': 95 }

class Encrypt():


    """
    This is the constructor
    """
    def __init__(self):
        self.encryptList = []
        self.mykey = 0
    """
    This method takes a string and maps it's number equivelence and puts into a list
    Parameter 1: It is a String, and it is the message that will be encrypted 
    Returns a list  
    """
    def map(self, string1):
        mapList = []
        for i in string1:
            mapList.append(mapDict[i])
        return mapList


    """
    This method takes the public key, and the list from the map() method, and encrypts 
    and returns the ecrypted message.
    Parameter 1: mapList, it is a list that contains the mapped message
    Parameter 2: N it is an integer, it is the public key 
    Parameter 3: e it is an integer, it is also the public key
    Returns a list with the encrypted message
    """
    def encrypt(self, mapList, N, e):
        self.encryptList = []
        for i in mapList:
            c = (i ** e) % (N) 
            self.encryptList.append(c)
        return self.encryptList
    
    """
    This method exports the encrypted message to a csv file
    """
    def exportCSV(self):
        with open("encryptedCSV.csv", "w") as f:
            csvList = []
            for num in self.encryptList:#Convert it 
                csvList.append(str(num))
            encryptString = ",".join(csvList)
            f.write(encryptString)
        f.close()

    """
    This method imports the public key to encrypt the message
    """
    def importPublicKey(self):
        with open("mypublickey.pem", "r") as f:
            data = f.read()
            self.mykey = RSA.import_key(data)
        f.close()




#____________________________________________________________________________________________________
encryptMsg = Encrypt()# Create object

encryptMsg.importPublicKey()#Get keys 

encryptList = encryptMsg.map(sys.argv[1]) #Get string from arguments and map string

encryptMsg.encrypt(encryptList, encryptMsg.mykey.n, encryptMsg.mykey.e)#Encrypt the mapped string 

encryptMsg.exportCSV() #Export the encrypted string to a csv file
#_____________________________________________________________________________________________________

        